# Digimon Dex

A SwiftUI + Combine iOS app that fetches Digimon data from the [Digimon API](https://digimon-api.vercel.app/api/digimon) and presents it in a polished browsing experience.

## Architecture

The project follows **MVVM** with **Clean Architecture** layering:

```
DigimonDex/
├── App/                    # App entry point
├── Presentation/           # Views, ViewModels, UI components
├── Domain/                 # Entities, repository protocols, use cases
├── Data/                   # DTOs, API service, repository implementations
├── Core/                   # Theme, dependency injection
└── Resources/              # Assets, Info.plist
```

### Data flow

1. **View** observes `DigimonListViewModel` and renders UI state.
2. **ViewModel** calls `FetchDigimonListUseCase` via Combine publishers.
3. **Use case** delegates to `DigimonRepositoryProtocol`.
4. **Repository** calls `DigimonAPIService`, maps DTOs to domain entities, and returns sorted results.

Networking stays in the **Data** layer. Views contain no API or URLSession code.

## Features

- Grid list of Digimon with images, names, and level badges
- Search by name
- Filter by evolution level
- Pull to refresh
- Detail screen with profile info
- Loading, empty, and error states with retry

## Requirements

- Xcode 15+
- iOS 17+

## Getting started

1. Open `DigimonDex.xcodeproj` in Xcode.
2. Select an iPhone simulator or device.
3. Build and run (`⌘R`).

## API

```
GET https://digimon-api.vercel.app/api/digimon
```

Response fields: `name`, `img`, `level`.
