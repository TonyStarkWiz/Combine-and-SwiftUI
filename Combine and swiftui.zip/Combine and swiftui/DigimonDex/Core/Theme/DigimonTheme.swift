// Centralized design tokens keep colors and gradients consistent across all Views.
import SwiftUI

enum DigimonTheme {
    static let backgroundTop = Color(red: 0.06, green: 0.08, blue: 0.18)
    static let backgroundBottom = Color(red: 0.10, green: 0.14, blue: 0.28)
    static let cardBackground = Color(red: 0.14, green: 0.18, blue: 0.32)
    static let cardBorder = Color.white.opacity(0.08)
    static let accentOrange = Color(red: 1.0, green: 0.55, blue: 0.12)
    static let accentBlue = Color(red: 0.25, green: 0.65, blue: 1.0)
    static let textPrimary = Color.white
    static let textSecondary = Color.white.opacity(0.65)

    // Pure function: maps domain data (level) to a visual property (color).
    static func levelColor(for level: DigimonLevel) -> Color {
        switch level {
        case .fresh: return Color(red: 0.55, green: 0.85, blue: 0.95)
        case .inTraining, .training: return Color(red: 0.45, green: 0.75, blue: 1.0)
        case .rookie: return Color(red: 0.35, green: 0.85, blue: 0.55)
        case .champion: return Color(red: 1.0, green: 0.75, blue: 0.25)
        case .ultimate: return Color(red: 1.0, green: 0.45, blue: 0.35)
        case .mega: return Color(red: 0.85, green: 0.35, blue: 1.0)
        case .armor: return Color(red: 0.55, green: 0.65, blue: 1.0)
        case .unknown: return Color.gray
        }
    }

    // Computed property returning a SwiftUI LinearGradient view modifier value.
    static var backgroundGradient: LinearGradient {
        LinearGradient(
            colors: [backgroundTop, backgroundBottom],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
}

// Reusable background View — composition over duplicating ZStack code in every screen.
struct DigimonBackground: View {
    var body: some View {
        ZStack {
            DigimonTheme.backgroundGradient
                .ignoresSafeArea() // Extends gradient behind status bar and home indicator.

            // Decorative blurred circles add depth without affecting layout (no hit testing).
            Circle()
                .fill(DigimonTheme.accentOrange.opacity(0.12))
                .frame(width: 320, height: 320)
                .blur(radius: 60)
                .offset(x: -120, y: -280)

            Circle()
                .fill(DigimonTheme.accentBlue.opacity(0.10))
                .frame(width: 280, height: 280)
                .blur(radius: 50)
                .offset(x: 140, y: 320)
        }
    }
}
