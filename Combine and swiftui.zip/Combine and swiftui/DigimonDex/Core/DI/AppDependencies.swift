// Composition Root: the one place that wires concrete types into the object graph.
import Foundation

enum AppDependencies {
    // @MainActor required because DigimonListViewModel's initializer is main-actor isolated.
    @MainActor
    static func makeDigimonListViewModel() -> DigimonListViewModel {
        // Manual dependency injection — build from the inside out:
        // Service → Repository → UseCase → ViewModel
        let apiService = DigimonAPIService()
        let repository = DigimonRepository(apiService: apiService)
        let useCase = FetchDigimonListUseCase(repository: repository)
        return DigimonListViewModel(fetchDigimonListUseCase: useCase)
    }
}
