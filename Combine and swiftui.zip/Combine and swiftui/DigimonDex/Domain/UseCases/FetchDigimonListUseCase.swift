import Combine

// Use-case protocol lets the ViewModel depend on behavior, not implementation details.
protocol FetchDigimonListUseCaseProtocol {
    func execute() -> AnyPublisher<[Digimon], Error>
}

// Use Case pattern: one class = one application action (fetch the Digimon list).
// Keeps ViewModels thin and business rules out of Views and network code.
struct FetchDigimonListUseCase: FetchDigimonListUseCaseProtocol {
    // Constructor injection: dependencies are passed in, not created inside.
    private let repository: DigimonRepositoryProtocol

    init(repository: DigimonRepositoryProtocol) {
        self.repository = repository
    }

    func execute() -> AnyPublisher<[Digimon], Error> {
        repository.fetchDigimon()
    }
}
