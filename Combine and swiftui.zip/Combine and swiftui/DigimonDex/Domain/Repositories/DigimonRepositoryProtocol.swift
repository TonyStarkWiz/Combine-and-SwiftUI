import Combine

// Protocol (interface) in the Domain layer — Dependency Inversion Principle.
// The ViewModel depends on this abstraction, not on a concrete API or database class.
protocol DigimonRepositoryProtocol {
    // AnyPublisher<Output, Failure> is Combine's reactive stream type for async data.
    func fetchDigimon() -> AnyPublisher<[Digimon], Error>
}
