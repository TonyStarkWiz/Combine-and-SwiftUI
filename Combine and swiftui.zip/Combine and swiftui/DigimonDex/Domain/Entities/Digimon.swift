// Domain layer: pure business models with no UI or networking dependencies.
import Foundation

// Identifiable → required by SwiftUI ForEach when not using explicit id:.
// Equatable + Hashable → enables value comparison and NavigationStack(value:) routing.
struct Digimon: Identifiable, Equatable, Hashable {
    let id: String
    let name: String
    let imageURL: URL?
    let level: DigimonLevel

    init(id: String? = nil, name: String, imageURL: URL?, level: DigimonLevel) {
        // Nil-coalescing gives each Digimon a stable identity for list diffing and navigation.
        self.id = id ?? name
        self.name = name
        self.imageURL = imageURL
        self.level = level
    }
}

// String-backed enum: rawValue maps directly to API strings like "Rookie" or "Mega".
// CaseIterable → iterate all cases (used to build level filter chips in sort order).
enum DigimonLevel: String, CaseIterable, Codable {
    case fresh = "Fresh"
    case inTraining = "In Training"
    case training = "Training"
    case rookie = "Rookie"
    case champion = "Champion"
    case ultimate = "Ultimate"
    case mega = "Mega"
    case armor = "Armor"
    case unknown = "Unknown"

    // Failable init via rawValue; fallback keeps the app resilient to unexpected API values.
    init(rawAPIValue: String) {
        self = DigimonLevel(rawValue: rawAPIValue) ?? .unknown
    }

    // Computed property: domain logic for sorting lives in the entity, not the ViewModel.
    var sortOrder: Int {
        switch self {
        case .fresh: return 0
        case .inTraining, .training: return 1
        case .rookie: return 2
        case .champion: return 3
        case .ultimate: return 4
        case .mega: return 5
        case .armor: return 6
        case .unknown: return 7
        }
    }

    var displayName: String { rawValue }
}
