// Detail screen receives a Digimon value — no re-fetch needed; data was passed via navigation.
import SwiftUI

struct DigimonDetailView: View {
    let digimon: Digimon

    var body: some View {
        ZStack {
            DigimonBackground()

            ScrollView {
                VStack(spacing: 24) {
                    heroImage

                    VStack(spacing: 12) {
                        Text(digimon.name)
                            .font(.system(size: 34, weight: .bold, design: .rounded))
                            .foregroundStyle(DigimonTheme.textPrimary)
                            .multilineTextAlignment(.center)

                        LevelBadge(level: digimon.level, style: .prominent)
                    }

                    infoCard
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 20)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
    }

    // Extracted sub-views as computed properties keep `body` readable (View composition).
    private var heroImage: some View {
        ZStack {
            Circle()
                .fill(
                    // RadialGradient radiates color outward from the center — good for spotlight effects.
                    RadialGradient(
                        colors: [
                            DigimonTheme.levelColor(for: digimon.level).opacity(0.45),
                            .clear
                        ],
                        center: .center,
                        startRadius: 20,
                        endRadius: 160
                    )
                )
                .frame(width: 280, height: 280)

            DigimonAsyncImage(url: digimon.imageURL)
                .frame(width: 220, height: 220)
        }
        .padding(.top, 12)
    }

    private var infoCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Profile")
                .font(.title3.weight(.semibold))
                .foregroundStyle(DigimonTheme.textPrimary)

            DetailRow(title: "Name", value: digimon.name)
            DetailRow(title: "Level", value: digimon.level.displayName)
            // Ternary operator derives display text from domain sortOrder — presentation logic only.
            DetailRow(title: "Classification", value: digimon.level.sortOrder >= DigimonLevel.champion.sortOrder ? "Battle Ready" : "In Development")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(DigimonTheme.cardBackground)
                .overlay(
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .stroke(DigimonTheme.cardBorder, lineWidth: 1)
                )
        )
    }
}

// private struct scoped to this file — encapsulates a small reusable row layout.
private struct DetailRow: View {
    let title: String
    let value: String

    var body: some View {
        HStack {
            Text(title)
                .font(.subheadline)
                .foregroundStyle(DigimonTheme.textSecondary)

            Spacer() // Pushes value to the trailing edge.

            Text(value)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(DigimonTheme.textPrimary)
        }
    }
}

#Preview {
    NavigationStack {
        DigimonDetailView(
            digimon: Digimon(
                name: "WarGreymon",
                imageURL: URL(string: "https://digimon.shadowsmith.com/img/wargreymon.jpg"),
                level: .mega
            )
        )
    }
}
