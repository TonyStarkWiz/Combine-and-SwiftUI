// MVVM View: only responsible for layout and forwarding user actions to the ViewModel.
import SwiftUI

struct DigimonListView: View {
    // @StateObject owns the ViewModel's lifecycle — created once, survives View re-creation.
    @StateObject private var viewModel: DigimonListViewModel

    // GridItem(.flexible()) creates equal-width columns that share available space.
    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]

    // Separate inits avoid calling @MainActor code from a default-parameter context (nonisolated).
    init() {
        _viewModel = StateObject(wrappedValue: AppDependencies.makeDigimonListViewModel())
    }

    // Previews and tests inject a custom ViewModel through this initializer.
    init(viewModel: DigimonListViewModel) {
        // StateObject requires _propertyName = StateObject(wrappedValue:) in custom inits.
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    var body: some View {
        NavigationStack { // iOS 16+ type-safe navigation (replaces NavigationView + NavigationLink isActive)
            ZStack {
                DigimonBackground()

                content
            }
            .navigationTitle("Digimon Dex")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(.hidden, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .task { // Structured concurrency: runs async work when the View appears; cancelled on disappear.
                if viewModel.viewState == .idle {
                    viewModel.loadDigimon()
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    // @ViewBuilder lets this computed property return different View types from each switch case.
    @ViewBuilder
    private var content: some View {
        switch viewModel.viewState {
        // `where` clause: show full-screen loading only on first load, not during pull-to-refresh.
        case .idle, .loading where viewModel.digimon.isEmpty:
            LoadingView(message: "Summoning Digimon...")
        case .error(let message):
            ErrorView(message: message, retryAction: viewModel.retry)
        case .empty:
            EmptyStateView(
                title: "No Digimon Found",
                subtitle: "The Digital World is quiet right now.",
                actionTitle: "Try Again",
                action: viewModel.retry
            )
        default:
            mainContent
        }
    }

    private var mainContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                headerSection

                if viewModel.viewState == .loading {
                    ProgressView()
                        .tint(DigimonTheme.accentOrange)
                        .frame(maxWidth: .infinity)
                }

                if viewModel.filteredDigimon.isEmpty {
                    EmptyStateView(
                        title: "No Matches",
                        subtitle: "Try a different search or level filter.",
                        actionTitle: "Clear Filters",
                        action: viewModel.clearFilters
                    )
                    .padding(.top, 40)
                } else {
                    digimonGrid
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 24)
        }
        .refreshable { // Native pull-to-refresh; calls loadDigimon on the ViewModel.
            viewModel.loadDigimon()
        }
    }

    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Explore the Digital World")
                .font(.subheadline)
                .foregroundStyle(DigimonTheme.textSecondary)

            // $viewModel.searchText creates a Binding<String> for two-way data flow.
            DigimonSearchBar(text: $viewModel.searchText)

            LevelFilterChips(
                levels: viewModel.availableLevels,
                selectedLevel: viewModel.selectedLevel,
                onSelect: viewModel.selectLevel // Method reference passes the action as a closure.
            )

            HStack {
                Text("\(viewModel.filteredDigimon.count) Digimon")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(DigimonTheme.textSecondary)

                Spacer()

                if viewModel.selectedLevel != nil || !viewModel.searchText.isEmpty {
                    Button("Clear", action: viewModel.clearFilters)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(DigimonTheme.accentBlue)
                }
            }
        }
        .padding(.top, 8)
    }

    private var digimonGrid: some View {
        // LazyVGrid only creates cells for visible rows — important for large lists.
        LazyVGrid(columns: columns, spacing: 16) {
            ForEach(viewModel.filteredDigimon) { digimon in
                // Value-based NavigationLink pushes DigimonDetailView when tapped.
                NavigationLink(value: digimon) {
                    DigimonCardView(digimon: digimon)
                }
                .buttonStyle(.plain) // Removes default NavigationLink blue tint and chevron styling.
            }
        }
        .navigationDestination(for: Digimon.self) { digimon in
            DigimonDetailView(digimon: digimon)
        }
    }
}

#Preview("Loaded") {
    DigimonListView(viewModel: .preview())
}

#Preview("Error") {
    DigimonListView(viewModel: .preview(shouldFail: true))
}
