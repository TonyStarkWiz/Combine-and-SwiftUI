// Stateless View: receives all data via `let` properties — no ViewModel dependency.
import SwiftUI

struct DigimonCardView: View {
    let digimon: Digimon

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(
                        // LinearGradient fills the card header with a level-tinted background.
                        LinearGradient(
                            colors: [
                                DigimonTheme.levelColor(for: digimon.level).opacity(0.25),
                                DigimonTheme.cardBackground
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )

                DigimonAsyncImage(url: digimon.imageURL)
                    .padding(12)
            }
            .frame(height: 130)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

            VStack(alignment: .leading, spacing: 6) {
                Text(digimon.name)
                    .font(.headline)
                    .foregroundStyle(DigimonTheme.textPrimary)
                    .lineLimit(1) // Truncates long names with "..." instead of wrapping.

                LevelBadge(level: digimon.level)
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(DigimonTheme.cardBackground)
                .overlay(
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .stroke(DigimonTheme.cardBorder, lineWidth: 1)
                )
        )
        .shadow(color: .black.opacity(0.18), radius: 10, y: 6)
    }
}

#Preview {
    DigimonCardView(
        digimon: Digimon(
            name: "Agumon",
            imageURL: URL(string: "https://digimon.shadowsmith.com/img/agumon.jpg"),
            level: .rookie
        )
    )
    .padding()
    .background(DigimonTheme.backgroundGradient)
}
