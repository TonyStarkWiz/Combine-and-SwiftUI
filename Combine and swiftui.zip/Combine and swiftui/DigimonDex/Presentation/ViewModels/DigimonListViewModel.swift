import Combine
import Foundation

// Enum models UI state explicitly — safer than scattered Bool flags (isLoading, hasError, etc.).
enum DigimonListViewState: Equatable {
    case idle
    case loading
    case loaded
    case empty
    case error(String) // Associated value carries the error message for display.
}

// @MainActor guarantees all property updates happen on the main thread (required for SwiftUI).
@MainActor
// ObservableObject + @Published → SwiftUI Views re-render when these properties change.
final class DigimonListViewModel: ObservableObject {
    @Published private(set) var digimon: [Digimon] = []       // private(set) = read-only from outside
    @Published private(set) var viewState: DigimonListViewState = .idle
    @Published var searchText = ""                             // Two-way bound to the search bar
    @Published var selectedLevel: DigimonLevel?

    private let fetchDigimonListUseCase: FetchDigimonListUseCaseProtocol
    // Set<AnyCancellable> retains subscriptions; when deallocated, Combine cancels them.
    private var cancellables = Set<AnyCancellable>()

    // Computed property: derived state recalculates whenever digimon, searchText, or selectedLevel change.
    var filteredDigimon: [Digimon] {
        digimon.filter { digimon in
            let matchesSearch = searchText.isEmpty
                || digimon.name.localizedCaseInsensitiveContains(searchText)

            let matchesLevel = selectedLevel == nil || digimon.level == selectedLevel

            return matchesSearch && matchesLevel
        }
    }

    var availableLevels: [DigimonLevel] {
        let levels = Set(digimon.map(\.level)) // Set removes duplicates
        return DigimonLevel.allCases.filter { levels.contains($0) }
    }

    init(fetchDigimonListUseCase: FetchDigimonListUseCaseProtocol) {
        self.fetchDigimonListUseCase = fetchDigimonListUseCase
    }

    func loadDigimon() {
        guard viewState != .loading else { return } // Prevents duplicate in-flight requests

        viewState = .loading

        fetchDigimonListUseCase.execute()
            .receive(on: DispatchQueue.main) // Ensures sink closures run on the main thread
            .sink { [weak self] completion in
                // [weak self] avoids a retain cycle between ViewModel and the subscription.
                guard let self else { return }

                if case .failure(let error) = completion {
                    self.viewState = .error(error.localizedDescription)
                }
            } receiveValue: { [weak self] digimon in
                guard let self else { return }

                self.digimon = digimon
                self.viewState = digimon.isEmpty ? .empty : .loaded
            }
            .store(in: &cancellables) // Keeps the subscription alive for the ViewModel's lifetime
    }

    func retry() {
        loadDigimon()
    }

    func clearFilters() {
        searchText = ""
        selectedLevel = nil
    }

    // Toggle behavior: tapping the same chip again deselects it.
    func selectLevel(_ level: DigimonLevel?) {
        selectedLevel = selectedLevel == level ? nil : level
    }
}
