import Combine
import Foundation

// #if DEBUG strips this entire file from Release builds — zero cost in production.
#if DEBUG
enum DigimonPreviewData {
    static let sample: [Digimon] = [
        Digimon(name: "Agumon", imageURL: URL(string: "https://digimon.shadowsmith.com/img/agumon.jpg"), level: .rookie),
        Digimon(name: "Gabumon", imageURL: URL(string: "https://digimon.shadowsmith.com/img/gabumon.jpg"), level: .rookie),
        Digimon(name: "Greymon", imageURL: URL(string: "https://digimon.shadowsmith.com/img/greymon.jpg"), level: .champion),
        Digimon(name: "WarGreymon", imageURL: URL(string: "https://digimon.shadowsmith.com/img/wargreymon.jpg"), level: .mega)
    ]
}

// Test Double: conforms to the same protocol as the real repository but returns fake data.
final class MockDigimonRepository: DigimonRepositoryProtocol {
    private let digimon: [Digimon]
    private let shouldFail: Bool

    init(digimon: [Digimon] = DigimonPreviewData.sample, shouldFail: Bool = false) {
        self.digimon = digimon
        self.shouldFail = shouldFail
    }

    func fetchDigimon() -> AnyPublisher<[Digimon], Error> {
        if shouldFail {
            // Fail publisher immediately emits a single error then completes.
            return Fail(error: DigimonAPIError.invalidResponse).eraseToAnyPublisher()
        }

        // Just publisher emits a value synchronously — ideal for deterministic previews.
        return Just(digimon)
            .setFailureType(to: Error.self) // Upgrades Never failure type to Error for protocol conformance.
            .delay(for: .milliseconds(300), scheduler: DispatchQueue.main) // Simulates network latency.
            .eraseToAnyPublisher()
    }
}

extension DigimonListViewModel {
    @MainActor
    static func preview(
        digimon: [Digimon] = DigimonPreviewData.sample,
        shouldFail: Bool = false
    ) -> DigimonListViewModel {
        let repository = MockDigimonRepository(digimon: digimon, shouldFail: shouldFail)
        let useCase = FetchDigimonListUseCase(repository: repository)
        let viewModel = DigimonListViewModel(fetchDigimonListUseCase: useCase)
        viewModel.loadDigimon()
        return viewModel
    }
}
#endif
