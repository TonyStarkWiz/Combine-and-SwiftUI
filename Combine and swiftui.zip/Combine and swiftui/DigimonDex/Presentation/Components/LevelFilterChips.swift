import SwiftUI

struct LevelFilterChips: View {
    let levels: [DigimonLevel]
    let selectedLevel: DigimonLevel?
    // Closure callback: child notifies parent of selection without owning the state.
    let onSelect: (DigimonLevel?) -> Void

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                // id: \.self because DigimonLevel is Hashable (required for value-type ForEach).
                ForEach(levels, id: \.self) { level in
                    Button {
                        onSelect(level)
                    } label: {
                        LevelBadge(level: level, style: selectedLevel == level ? .prominent : .compact)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.vertical, 2)
        }
    }
}

struct LevelBadge: View {
    // Nested enum defines visual variants without duplicating the entire View.
    enum Style {
        case compact
        case prominent
    }

    let level: DigimonLevel
    var style: Style = .compact // Default argument: callers can omit style for compact badges.

    var body: some View {
        Text(level.displayName)
            .font(style == .prominent ? .subheadline.weight(.semibold) : .caption.weight(.semibold))
            .foregroundStyle(style == .prominent ? .white : DigimonTheme.levelColor(for: level))
            .padding(.horizontal, style == .prominent ? 14 : 10)
            .padding(.vertical, style == .prominent ? 8 : 6)
            .background(
                Capsule() // Capsule = rounded rectangle with fully rounded ends (pill shape).
                    .fill(
                        style == .prominent
                            ? DigimonTheme.levelColor(for: level)
                            : DigimonTheme.levelColor(for: level).opacity(0.15)
                    )
            )
    }
}
