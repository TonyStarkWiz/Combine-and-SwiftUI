import SwiftUI

struct DigimonSearchBar: View {
    // @Binding: child View can read AND write a value owned by the parent (ViewModel).
    @Binding var text: String

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(DigimonTheme.textSecondary)

            TextField("Search Digimon", text: $text) // $text is the Binding passed to TextField.
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .foregroundStyle(DigimonTheme.textPrimary)

            if !text.isEmpty {
                Button {
                    text = "" // Writing to the Binding updates the ViewModel's searchText.
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(DigimonTheme.textSecondary)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(DigimonTheme.cardBackground)
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(DigimonTheme.cardBorder, lineWidth: 1)
                )
        )
    }
}
