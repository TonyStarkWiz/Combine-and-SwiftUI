import SwiftUI

struct DigimonAsyncImage: View {
    let url: URL?

    var body: some View {
        // Group wraps conditional branches so body returns a single opaque View type.
        Group {
            if let url {
                // AsyncImage loads remote images asynchronously and reports progress via `phase`.
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        placeholder       // Image is still downloading
                    case .success(let image):
                        image
                            .resizable()    // Allows the image to scale within its frame
                            .scaledToFit()   // Maintains aspect ratio, fits inside bounds
                    case .failure:
                        failureView         // Download or decode failed
                    @unknown default:       // Future AsyncImage phases won't break compilation
                        placeholder
                    }
                }
            } else {
                failureView // No URL provided — show fallback immediately
            }
        }
    }

    private var placeholder: some View {
        ProgressView()
            .tint(DigimonTheme.accentOrange)
    }

    private var failureView: some View {
        VStack(spacing: 8) {
            Image(systemName: "photo")
                .font(.title2)
            Text("No Image")
                .font(.caption)
        }
        .foregroundStyle(DigimonTheme.textSecondary)
    }
}
