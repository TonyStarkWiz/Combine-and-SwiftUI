// Reusable UI state Views — each accepts data + a closure, no ViewModel coupling.
import SwiftUI

struct LoadingView: View {
    let message: String

    var body: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.2)
                .tint(DigimonTheme.accentOrange)

            Text(message)
                .font(.headline)
                .foregroundStyle(DigimonTheme.textSecondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity) // Centers content in available space.
    }
}

struct ErrorView: View {
    let message: String
    let retryAction: () -> Void // Escaping closure: parent decides what "retry" means.

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 42))
                .foregroundStyle(DigimonTheme.accentOrange)

            Text("Connection Failed")
                .font(.title3.weight(.semibold))
                .foregroundStyle(DigimonTheme.textPrimary)

            Text(message)
                .font(.subheadline)
                .foregroundStyle(DigimonTheme.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 24)

            Button(action: retryAction) {
                Text("Retry")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .padding(.horizontal, 28)
                    .padding(.vertical, 12)
                    .background(
                        Capsule()
                            .fill(DigimonTheme.accentOrange)
                    )
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

struct EmptyStateView: View {
    let title: String
    let subtitle: String
    let actionTitle: String
    let action: () -> Void

    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: "sparkles")
                .font(.system(size: 36))
                .foregroundStyle(DigimonTheme.accentBlue)

            Text(title)
                .font(.title3.weight(.semibold))
                .foregroundStyle(DigimonTheme.textPrimary)

            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(DigimonTheme.textSecondary)
                .multilineTextAlignment(.center)

            Button(actionTitle, action: action)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(DigimonTheme.accentBlue)
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 24)
    }
}
