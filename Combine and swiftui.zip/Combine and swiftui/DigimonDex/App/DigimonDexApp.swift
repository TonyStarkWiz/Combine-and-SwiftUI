// App entry point — @main tells Swift this struct bootstraps the application.
import SwiftUI

@main
struct DigimonDexApp: App {
    var body: some Scene {
        // WindowGroup creates the primary app window (one on iPhone, multiple on iPad/macOS).
        WindowGroup {
            DigimonListView() // Root View of the app
        }
    }
}
