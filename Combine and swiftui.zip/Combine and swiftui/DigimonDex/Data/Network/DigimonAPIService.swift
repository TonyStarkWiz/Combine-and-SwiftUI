import Combine
import Foundation

// Protocol enables swapping real network calls with mocks in tests and previews.
protocol DigimonAPIServiceProtocol {
    func fetchDigimonList() -> AnyPublisher<[DigimonDTO], Error>
}

// LocalizedError provides user-facing error messages via error.localizedDescription.
enum DigimonAPIError: LocalizedError {
    case invalidURL
    case invalidResponse
    case decodingFailed

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "The Digimon API URL is invalid."
        case .invalidResponse:
            return "The server returned an unexpected response."
        case .decodingFailed:
            return "Unable to read Digimon data from the server."
        }
    }
}

// final class → no subclassing; appropriate for a concrete service type.
final class DigimonAPIService: DigimonAPIServiceProtocol {
    private let session: URLSession
    private let baseURL: URL

    // Default arguments make production wiring simple while tests can inject a custom session.
    init(
        session: URLSession = .shared,
        baseURL: URL = URL(string: "https://digimon-api.vercel.app/api")!
    ) {
        self.session = session
        self.baseURL = baseURL
    }

    func fetchDigimonList() -> AnyPublisher<[DigimonDTO], Error> {
        let endpoint = baseURL.appendingPathComponent("digimon")

        // dataTaskPublisher wraps URLSession in a Combine publisher (replaces callback-based API).
        return session.dataTaskPublisher(for: endpoint)
            // tryMap can throw; failures propagate downstream as publisher errors.
            .tryMap { data, response in
                guard let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode) else {
                    throw DigimonAPIError.invalidResponse
                }
                return data
            }
            // decode operator turns Data into a Decodable type using JSONDecoder.
            .decode(type: [DigimonDTO].self, decoder: JSONDecoder())
            .mapError { error in
                error is DecodingError ? DigimonAPIError.decodingFailed : error
            }
            // Type-erases the publisher chain so callers see a simple AnyPublisher type.
            .eraseToAnyPublisher()
    }
}
