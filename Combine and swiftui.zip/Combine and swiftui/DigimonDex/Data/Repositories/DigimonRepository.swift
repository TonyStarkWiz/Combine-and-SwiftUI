import Combine
import Foundation

// Repository pattern: single place that decides where data comes from (API, cache, DB).
final class DigimonRepository: DigimonRepositoryProtocol {
    private let apiService: DigimonAPIServiceProtocol

    init(apiService: DigimonAPIServiceProtocol) {
        self.apiService = apiService
    }

    func fetchDigimon() -> AnyPublisher<[Digimon], Error> {
        apiService.fetchDigimonList()
            // map transforms each emitted value without changing success/failure semantics.
            .map { dtos in
                dtos
                    .map { $0.toDomain() } // DTO → Domain entity
                    .sorted {
                        // Multi-criteria sort: primary by evolution level, secondary by name.
                        if $0.level.sortOrder != $1.level.sortOrder {
                            return $0.level.sortOrder < $1.level.sortOrder
                        }
                        // localizedCaseInsensitiveCompare respects locale-aware alphabetical order.
                        return $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
                    }
            }
            .eraseToAnyPublisher()
    }
}
