// Data Transfer Object: mirrors the JSON shape from the API exactly.
import Foundation

// Decodable → Swift synthesizes init(from:) from JSON keys (name, img, level).
struct DigimonDTO: Decodable {
    let name: String
    let img: String
    let level: String

    // Mapping layer: converts wire-format (DTO) into a clean Domain entity.
    // Domain models never know about JSON field names like "img".
    func toDomain() -> Digimon {
        Digimon(
            name: name,
            imageURL: URL(string: img), // String → URL?; invalid URLs become nil safely.
            level: DigimonLevel(rawAPIValue: level)
        )
    }
}
